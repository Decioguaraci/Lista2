﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2_exercicio11
{
    class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;
            double p3;
            Console.WriteLine("Digite o valor da P1 e obtenha o minimo de valor que deverá tirar na P2");
            Console.WriteLine("Digite o valor da P1: ");
            p1 = double.Parse(Console.ReadLine());
            if (p1 >= 5)
            {
                Console.WriteLine("Você deverá obter um valor maior ou igual a 5");
            }
            else
                if (p1 == 4)
            {
                Console.WriteLine("Você deverá obter um valor maior ou igual a 6");
            }
            else
                if (p1 == 3)
            {
                Console.WriteLine("Você deverá obter um valor maior ou igual a 6");
            }
            else
                if (p1 <= 2)
            {
                Console.WriteLine("Você deverá obter um valor maior ou igual a 7");
            }
            Console.Read();
        }
    }
}
