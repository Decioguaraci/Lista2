﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2_exercicio6
{
    class Program
    {
        static void Main(string[] args)
        {
            double altura;
            double peso;
            double resultado;
            double x;

            Console.WriteLine("Calcule o IMC a partir deste programa");
            Console.WriteLine("Digite a altura em metros");
            altura = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o peso em quilogramas");
            peso = double.Parse(Console.ReadLine());
            x = altura * altura;
            resultado = peso / x;

            if (resultado < 20)
            {
                Console.WriteLine("Abaixo do peso");
            }
            if (resultado > 25) 

            {
                Console.WriteLine("Acima do peso");
            }

            if (resultado >= 20)
                if (resultado >= 25)
                {
                    Console.WriteLine("Peso ideal");
                }
                    Console.ReadLine();

        }
    }
}
