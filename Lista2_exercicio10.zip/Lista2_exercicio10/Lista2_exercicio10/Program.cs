﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista2_exercicio10
{
    class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;
            double media;
            double x;
            Console.WriteLine("Obtenha o seu resultado final");
            Console.WriteLine("Digite o valor da P1");
            p1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o valor da P2");
            p2 = double.Parse(Console.ReadLine());
            x = 2 * p2;
            media = (p1 + x) / 3;
            if (media >= 5)
            {
                Console.WriteLine("Aprovado");
            }
            else
                if (media < 5)
            {
                Console.WriteLine("Reprovodo");
            }
        }

    }
}
